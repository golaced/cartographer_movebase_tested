^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_calibration
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.6 (2016-06-29)
------------------

2.3.5 (2016-06-28)
------------------

2.3.4 (2016-06-28)
------------------

2.3.3 (2015-03-23)
------------------

2.3.2 (2015-01-21)
------------------

2.3.1 (2014-12-30)
------------------

2.3.0 (2014-12-30)
------------------
* Merge pull request `#83 <https://github.com/turtlebot/turtlebot_apps/issues/83>`_ from kbogert/hydro-devel
  Implement automatic calibration system
* Contributors: Jihoon Lee

2.2.4 (2013-10-14)
------------------

2.2.3 (2013-09-27)
------------------

2.2.2 (2013-09-26)
------------------

2.2.1 (2013-09-23)
------------------

2.2.0 (2013-08-30)
------------------
* Add bugtracker and repo info URLs.
* Changelogs at package level.

2.1.x - hydro, unstable
=======================

2.1.1 (2013-08-09)
------------------

2.1.0 (2013-07-19)
------------------
* Catkinized


Previous versions, bugfixing
============================

Available in ROS wiki: http://ros.org/wiki/turtlebot_apps/ChangeList
